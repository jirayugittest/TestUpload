﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsForeces
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DirectoryInfo info = new DirectoryInfo(@"D:\TESTGIT");
            FileInfo[] files = info.GetFiles().OrderBy(p => p.CreationTime).ToArray();
            FileInfo[] filesG = info.GetFiles().OrderByDescending(p => p.CreationTime).ToArray();

            foreach (FileInfo file in filesG)
            {
                // DO Something...
                listBox1.Items.Add(file.FullName + " - " + file.CreationTime);

            }
        }
    }
}
